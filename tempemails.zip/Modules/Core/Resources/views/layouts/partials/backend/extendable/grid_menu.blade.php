<div class="site-gridmenu">
    <div>
        <div>
            <ul>
                {{ loadExtendableView("grid_menu") }}
            </ul>
        </div>
    </div>
</div>
