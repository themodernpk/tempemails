<?php
/*
|--------------------------------------------------------------------------
| Cron Jobs
|--------------------------------------------------------------------------
*/
Route::group(
    [
        'middleware' => ['web'],
        'prefix' => 'cron',
        'namespace' => 'Modules\TempEmails\Http\Controllers'
    ],
    function () {
        //------------------------------------------------
        Route::any('/per/minute', 'CronController@perMinute')
            ->name('te.cron.per.minute');
        //------------------------------------------------
        Route::any('/per/minute', 'CronController@perMinute')
            ->name('te.cron.per.minute');
        //------------------------------------------------
        Route::any('/auth/pusher', 'CronController@authPusher')
            ->name('te.pusher');
        //------------------------------------------------
    });
/*
|--------------------------------------------------------------------------
| Public
|--------------------------------------------------------------------------
*/
Route::group(
    [
        'middleware' => ['web'],
        'namespace' => 'Modules\TempEmails\Http\Controllers'
    ],
    function () {
        //------------------------------------------------
        Route::any('/', 'TempEmailsController@index')
            ->name('te.index');
        //------------------------------------------------
        Route::any('/apps', 'TempEmailsController@apps')
            ->name('te.apps');
        //------------------------------------------------
        Route::any('/accounts', 'TempEmailsController@accounts')
            ->name('te.account');
        //------------------------------------------------
        Route::any('/account/list', 'TempEmailsController@accountList')
            ->name('te.account.list');
        //------------------------------------------------
        Route::any('/email/list', 'TempEmailsController@emailList')
            ->name('te.email.list');
        //------------------------------------------------
        Route::any('/email/details', 'TempEmailsController@emailDetails')
            ->name('te.email.details');
        //------------------------------------------------
        Route::any('/email/iframe/{id}', 'TempEmailsController@emailiFrame')
            ->name('te.email.iframe');
        //------------------------------------------------
        Route::any('/generate/account', 'TempEmailsController@generateAccount')
            ->name('te.generate.account');
        //------------------------------------------------
        Route::any('/delete/account', 'TempEmailsController@deleteAccount')
            ->name('te.delete.account');
        //------------------------------------------------
        Route::any('/mark/all/read', 'TempEmailsController@markAllAsRead')
            ->name('te.mark.all.read');
        //------------------------------------------------
    });

/*
|--------------------------------------------------------------------------
| BD Test Reports
|--------------------------------------------------------------------------
*/
/*Route::group(
    [
        'middleware' => [ 'web', 'core.backend' ],
        'prefix'     => 'backend/gn',
        'namespace'  => 'Modules\General\Http\Controllers'
    ],
    function () {
        //------------------------------------------------
        Route::get( '/labels', 'LabelController@index' )
            ->name( 'gn.labels' );


        //------------------------------------------------
    });*/