<div class="page-header">
    <h1 class="page-title">Dashboard</h1>

</div>

<div class="page-content container-fluid">

    <p>Dashboard content</p>

</div>
