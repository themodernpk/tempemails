<li>
    <a href="apps/mailbox/mailbox.html">
        <i class="icon wb-envelope"></i>
        <span>Mailbox</span>
    </a>
</li>
<li>
    <a href="apps/calendar/calendar.html">
        <i class="icon wb-calendar"></i>
        <span>Calendar</span>
    </a>
</li>
