<a class="dropdown-item" href="javascript:void(0)"
   role="menuitem">
    <i class="icon wb-settings"aria-hidden="true"></i> Settings
</a>

<a class="dropdown-item" href="{{\URL::route('core.backend.user.profile')}}"
   role="menuitem">
    <i class="icon wb-user"aria-hidden="true"></i> Profile
</a>

<div class="dropdown-divider" role="presentation"></div>

<a class="dropdown-item" href="{{URL::route('core.backend.logout')}}"
   role="menuitem"><i class="icon wb-power" aria-hidden="true"></i> Logout
</a>
