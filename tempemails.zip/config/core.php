<?php

return [
    'name' => 'Core',
	'version' => '0.1'
];
