<div class="col-xs-6">
    <div class="counter">
        <div class="counter-label total-completed">USERS</div>
        <div class="counter-number red-600">{{$data->item->users_count}}</div>
    </div>
</div>
<div class="col-xs-6">
    <div class="counter">
        <div class="counter-label">PERMISSIONS</div>
        <div class="counter-number blue-600">{{$data->item->permissions_count}}</div>
    </div>
</div>
