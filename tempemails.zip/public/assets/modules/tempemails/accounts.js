

//#########################Vue#################################################
const app = new VueCommon({
    el: '#app',
    data: {

        //---------------------Pagination
        pagination:{},
        current_page: null,
        total_page: null,
        per_page: null,
        //---------------------End of Pagination
        accounts: [],
        account_active: null,
        emails: null,
        email_active: null,
        email_fetched: null,
        new_email: null,

    },
    mounted: function () {
        //---------------------------------------------------------------
        var geturl = [];
        $("input[data-type=url]").each(function () {
            var name = $(this).attr('name');
            var value = $(this).val();
            geturl[name] = value;
        });
        this.urls = geturl;
        //---------------------------------------------------------------
        this.listAccounts();
        //---------------------------------------------------------------
/*        setInterval(function () {
            this.silentFetch();
        }.bind(this), 5000);*/
        //---------------------------------------------------------------
        var pusher = new Pusher('3ee8efc1b5ea9de4411b', {
            authEndpoint: this.urls.base+'/cron/auth/pusher',
            cluster: 'ap2',
            auth: {
                headers: {
                    'X-CSRF-Token': document.querySelector('meta[name=csrf-token]').getAttribute('content')
                }
            }
        });

        var channel = pusher.subscribe('private-account.11');

        var self = this;

        channel.bind("email.created", function(data) {
            self.silentFetch();
            console.log("event", data);
        });

        //---------------------------------------------------------------
    },
    methods:{
        //---------------------------------------------------------------------
        //---------------------------------------------------------------------
        silentFetch: function () {
            var url = this.urls.base+"/account/list";
            var params = {};
            this.$http.post(url, params)
                .then(response => {
                    this.accounts = response.data.data;
                });

            if(this.account_active)
            {
                var url = this.urls.base+"/email/list";
                var params = {te_account_id: this.account_active.id};
                this.$http.post(url, params)
                    .then(response => {
                        this.emails = response.data.data.data;
                    });
            }

        },
        //---------------------------------------------------------------------
        listAccounts: function () {
            var url = this.urls.base+"/account/list";
            var params = {};
            this.processHttpRequest(url, params, this.listAccountsAfter);
        },
        //---------------------------------------------------------------------
        listAccountsAfter: function (data) {
            NProgress.done();
            this.accounts = data;
        },
        //---------------------------------------------------------------------
        generateAccount: function () {
            var url = this.urls.base+"/generate/account";
            var params = {};
            this.processHttpRequest(url, params, this.generateAccountAfter);
        },
        //---------------------------------------------------------------------
        generateAccountAfter: function (data) {
            NProgress.done();
            this.listAccounts();
        },
        //---------------------------------------------------------------------
        fetchEmails: function (event, account) {
              if(event)
            {
                event.preventDefault();
            }
            this.account_active = account;

            console.log(account);

            this.email_fetched = null;
            var url = this.urls.base+"/email/list";
            var params = {te_account_id: account.id};
            this.processHttpRequest(url, params, this.fetchEmailsAfter);
        },
        //---------------------------------------------------------------------
        fetchEmailsAfter: function (data) {
            NProgress.done();
            this.emails = [];
            this.emails = data.data;

            console.log("test");



        },

        //---------------------------------------------------------------------
        fetchEmail: function (event, email) {
            event.preventDefault();
            email.read = 1;
            this.email_active = email;
            this.emails = this.updateArray(this.emails, this.email_active);
            var url = this.urls.base+"/email/details";
            var params = {id: email.id};
            this.processHttpRequest(url, params, this.fetchEmailAfter);
        },
        //---------------------------------------------------------------------
        fetchEmailAfter: function (data) {
            NProgress.done();
            this.email_fetched = data;

            console.log("email fetched");



            this.activateTabs();


        },
        //---------------------------------------------------------------------
        activateTabs: function () {
            console.log('tabs=', $('body').delay( 1000 ).find('.tabs').length);
        },
        //---------------------------------------------------------------------
        deleteAccount: function (event, account) {
            var url = this.urls.base+"/delete/account";
            var params = {id: account.id};
            //this.removeFromArray(this.accounts, account);

            console.log(url);

            if(this.account_active.id == account.id)
            {
                this.account_active = null;
            }

            this.processHttpRequest(url, params, this.listAccounts);
        },
        //---------------------------------------------------------------------
        //---------------------------------------------------------------------
        tabs: function (event) {

            event.preventDefault();
            var element = event.target;

            $('body').find('.tabs a').each(function () {
                $(this).removeClass('active');
            });

            $('body').find('.tab-content').each(function () {
                $(this).attr('class', 'tab-content hide');
            });

            $(element).addClass('active');

            var content = $(element).attr('href');

            $(content).removeClass('hide');

        },
        //---------------------------------------------------------------------
        markAllAsRead: function (event, account) {
            var url = this.urls.base+"/mark/all/read";
            var params = {id: account.id};
            this.processHttpRequest(url, params, this.fetchEmails);
        },
        //---------------------------------------------------------------------
        //---------------------------------------------------------------------
        //---------------------------------------------------------------------
        //---------------------------------------------------------------------
    },
    //-------------------------------------------------------------------

    //-------------------------------------------------------------------
    //-------------------------------------------------------------------
    //-------------------------------------------------------------------
});


//#########################jQuery##############################################

(function (document, window, $) {


    //----------------------------------------------------------
    $('body').on('click', '#showHtmlSource', function () {
        hljs.initHighlighting.called = false;
        hljs.initHighlighting();
    });
    //----------------------------------------------------------
    //alertify.set('notifier','delay', 0);
    //----------------------------------------------------------
    $('body').on('click', '.clickToCopy', function (e) {
        e.preventDefault();
        alertify.success("Email Copied");
    });

    //----------------------------------------------------------



    //----------------------------------------------------------


    //----------------------------------------------------------
    //----------------------------------------------------------
    //----------------------------------------------------------


})(document, window, jQuery);