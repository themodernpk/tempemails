<div class="site-menubar">
    <ul class="site-menu" data-plugin="menu">
    {{ loadExtendableView("sidebar") }}
    </ul>
</div>
