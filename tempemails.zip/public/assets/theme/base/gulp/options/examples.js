// config
var config = require('../../config.json');
var styles = require('./styles');

module.exports = styles;
