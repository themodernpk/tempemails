<ul class="nav navbar-toolbar navbar-right navbar-toolbar-right">
    @include("core::layouts.partials.backend.extendable.top_user_menu")
    {{ loadExtendableView("top_right_menu") }}
</ul>
