<li class="nav-item dropdown dropdown-fw dropdown-mega">
    <a class="nav-link" data-toggle="dropdown" href="#" aria-expanded="false" data-animation="fade"
       role="button">Menu <i class="icon wb-chevron-down-mini" aria-hidden="true"></i></a>
    <div class="dropdown-menu" role="menu">
        <div class="mega-content">
            <div class="row">
                {{ loadExtendableView("mega_menu") }}
            </div>
        </div>
    </div>
</li>
