<?php
return [
    'smsFailed' => 'SMS Delivery Failed',
    'not-exist' => 'Record does not exist',
    'permission-denied' => 'Permission Denied',
];
