<form class="page-search-form" role="search">
    <div class="input-search input-search-dark">
        <i class="input-search-icon wb-search" aria-hidden="true"></i>
        <input type="text" class="form-control search"
               id="inputSearch" name="search"
               value=""
               placeholder="Search Users">
        <button type="button" class="input-search-close icon wb-close"
                aria-label="Close"></button>
    </div>
    <p class="text-help small m-l-45">Search like: name: pradeep, email: example@gmail.com, role: admin</p>
</form>
